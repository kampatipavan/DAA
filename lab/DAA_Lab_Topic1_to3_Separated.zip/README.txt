DAA Lab Exercise - Topics 1 to 3

Separated Python solutions based on the supplied DAA Lab Exercise PDF.

Folders:
- Topic 1 - Introduction (16 files)
- Topic 2 - Brute Force (14 files)
- Topic 3 - Divide and Conquer (16 files)

Total: 46 question files.
Each Qxx.py is standalone and can be run with Python 3.
Note: The PDF itself repeats numbering 15 in Topic 1; Q15 is Game of Life and Q16 is Champagne Tower.
